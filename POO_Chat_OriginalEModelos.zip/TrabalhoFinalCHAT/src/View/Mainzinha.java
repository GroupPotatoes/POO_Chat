package View;

/**
 * Classe que gera a Main.
 * @author Maiara Rodrigues
 */
public class Mainzinha {

    /**
     * Main
     * @param args the command line arguments
     */
    public static void main(String args[]) {        
        new LoginScreen().setVisible(true);
    }
}
